﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Inventor;

namespace Triangulator_InventorForm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        Inventor.Application _invApplication;
        Inventor.PartDocument _invPartDoc;
        Inventor.PartComponentDefinition _invPartCompDef;

        TransientGeometry _transientGeometry;
        Sketch _sketch;

        //Empty lists containing the elements of the mesh. Will gradually fill up to contain all elements of the triangulation.
        List<Point2d> _meshPoints = new List<Point2d>();
        List<Triangle> _meshTriangles = new List<Triangle>();

        List<Point2d> _listOfAllPoints = new List<Point2d>();

        private void OnConnectButtonClick(object sender, EventArgs e)
        {
            try
            {
                //Get the InventorApplication, PartDocument and PartComponentDefinition

                _invApplication = (Inventor.Application)System.Runtime.InteropServices.Marshal.GetActiveObject("Inventor.Application");
                if (null != _invApplication)
                {
                    _invPartDoc = (Inventor.PartDocument)_invApplication.ActiveDocument;
                    if (null != _invPartDoc)
                    {
                        _invPartCompDef = (Inventor.PartComponentDefinition)_invPartDoc.ComponentDefinition;
                        if (null != _invPartCompDef)
                            this.CollectPointsButton.Enabled = true;
                        else
                            MessageBox.Show("Error retrieving Part Component Definition");
                    }
                    else
                        MessageBox.Show("Part document must be open");
                }
                else
                    MessageBox.Show("Inventor must be running");
                return;
            }
            catch(Exception ex)
            {
                MessageBox.Show(e.ToString());
            }

        }

        private void OnCollectPointsButtonClick(object sender, EventArgs e)
        {
            try
            {
                //Retrieve points in the sketch and store them as data members

                _transientGeometry = _invApplication.TransientGeometry;
                _sketch = (Sketch)_invPartCompDef.Sketches[1];


                //Iterate through sketch points and add them to the _listOfAllPoints data member;
                if(0 == _sketch.SketchPoints.Count)
                {
                    MessageBox.Show("Sketch must contain points.");
                    return;
                }

                if (0 != _listOfAllPoints.Count)
                    _listOfAllPoints.Clear();
                if (0 != _meshPoints.Count)
                    _meshPoints.Clear();
                if (0 != _meshTriangles.Count)
                    _meshTriangles.Clear();
                
                //Skip first point in the sketch which is always the center point of the sketch
                for (int ii = 2; ii <= _sketch.SketchPoints.Count; ii++)
                    _listOfAllPoints.Add(_sketch.SketchPoints[ii].Geometry);

                this.BeginTriangulationButton.Enabled = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(e.ToString());
            }
        }

        private void OnBeginTriangulationButtonClick(object sender, EventArgs e)
        {
            try
            {
                DelaunayTriangulation();
                DisplayLines();
                this.BeginTriangulationButton.Enabled = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show(e.ToString());
            }
        }

        private void DelaunayTriangulation()
        {
            try
            {
                //List of points that lie inside the circumcircle. Will be cleared at end of each circumcircle-checking loop.
                List<Point2d> InCircumPoints = new List<Point2d>();

                /*Step 1: Create Supertriangle*/
                double dxmin = _listOfAllPoints[0].X;
                double dxmax = _listOfAllPoints[0].X;
                double dymin = _listOfAllPoints[0].Y;
                double dymax = _listOfAllPoints[0].Y;

                for (int ii = 1; ii < _listOfAllPoints.Count; ii++)
                {
                    if (_listOfAllPoints[ii].X < dxmin) dxmin = _listOfAllPoints[ii].X;
                    if (_listOfAllPoints[ii].X > dxmax) dxmax = _listOfAllPoints[ii].X;
                    if (_listOfAllPoints[ii].Y < dymin) dymin = _listOfAllPoints[ii].Y;
                    if (_listOfAllPoints[ii].Y > dymax) dymax = _listOfAllPoints[ii].Y;
                }

                double dx = dxmax - dxmin;
                double dy = dymax - dymin;
                double dmax = (dx > dy) ? dx : dy;
                double xmid = (dxmax + dxmin) / 2, ymid = (dymax + dymin) / 2;

                //These are the 3 supertriangle points with index of 0, 1 and 2. They will be removed at the end.
                _meshPoints.Add(_transientGeometry.CreatePoint2d(xmid, ymid + 2 * dmax));
                _meshPoints.Add(_transientGeometry.CreatePoint2d(xmid + 2 * dmax, ymid - dmax));
                _meshPoints.Add(_transientGeometry.CreatePoint2d(xmid - 2 * dmax, ymid - dmax));



                //This is the supertriangle. It has an index of 1 in the list.
                _meshTriangles.Add(new Triangle(_meshPoints[0], _meshPoints[1], _meshPoints[2]));

                /*Step 1 done*/

                /*Step 2: Add a new point*/
                for (int ii = 0; ii < _listOfAllPoints.Count; ii++)
                /*Step 2 done*/
                {
                    //The new meshpoint
                    _meshPoints.Add(_listOfAllPoints[ii]);
                    //Local variable of the same for ease of use
                    Point2d CurrentPoint = _listOfAllPoints[ii];

                    //Indices of the triangles made. Will be useful later
                    int nFirstTriangleIndex = 0;
                    int nSecondTriangleIndex = 0;
                    int nThirdTriangleIndex = 0;

                    /*Step 3: Find which triangle this point lies inside of*/

                    //To prevent infinite loop as _meshTriangles.Count keeps increasing in the next for loop
                    int InitialTriangleCount = _meshTriangles.Count;

                    for (int jj = 0; jj < InitialTriangleCount; jj++)
                    {
                        if (Tools.IsPointInsideTriangle(CurrentPoint, _meshTriangles[jj]))
                        /*Step 3 done*/
                        {
                            /*Step 4: Connect this point to the vertices of that triangle to make 3 new triangles and lines*/
                            //The integers are subtracted by 2 because one triangle will be removed at the end of this block
                            _meshTriangles.Add(new Triangle(CurrentPoint, _meshTriangles[jj].Point1, _meshTriangles[jj].Point2));
                            nFirstTriangleIndex = _meshTriangles.Count-2;
                            _meshTriangles.Add(new Triangle(CurrentPoint, _meshTriangles[jj].Point2, _meshTriangles[jj].Point3));
                            nSecondTriangleIndex = _meshTriangles.Count-2;
                            _meshTriangles.Add(new Triangle(CurrentPoint, _meshTriangles[jj].Point3, _meshTriangles[jj].Point1));
                            nThirdTriangleIndex = _meshTriangles.Count-2;
                            //These three are the newly made triangles. The indices are stored and used later.
                            //Next, delete the current triangle
                            _meshTriangles.RemoveAt(jj);
                            /*Step 4 done*/
                            break;
                        } // Add functionality for when the point is on the edge of a triangle


                    }

                    if (4 == _meshPoints.Count) continue; //Implies that only one point besides the supertria points are in the mesh, so no edge-flipping required.
                    
                    /*Step 5: Determine if the three edges of the newly formed triangle are valid.
                     If they are not, ValidEdge will perform Edge-Flipping till the edge is valid.*/
                    //Triangles are passed in reverse order. Important.
                    int FlipCount = 0;
                    FlipCount = ValidEdge(nThirdTriangleIndex, CurrentPoint);
                    //nSecondTriangleIndex is subtracted by FlipCount because, in the previous ValidEdge call, there
                    //will have been "FlipCount" number of edge-flips which deletes the same number of triangles
                    //below nSecondTriangleIndex. So the index of the triangle at nSecondTriangleIndex will move down
                    //by FlipCount.
                    FlipCount += ValidEdge(nSecondTriangleIndex - FlipCount, CurrentPoint);
                    FlipCount += ValidEdge(nFirstTriangleIndex - FlipCount, CurrentPoint);
                    /*Step 5 done*/
                }

                /*Step 6: Search for all triangles containing the supertriangle points and then delete them*/
                for (int ii = _meshTriangles.Count - 1; ii >= 0; ii--)
                {
                    if (_meshTriangles[ii].Point1 == _meshPoints[0] || _meshTriangles[ii].Point2 == _meshPoints[0] || _meshTriangles[ii].Point3 == _meshPoints[0])
                    {
                        _meshTriangles.RemoveAt(ii);
                        continue;
                    }

                    if (_meshTriangles[ii].Point1 == _meshPoints[1] || _meshTriangles[ii].Point2 == _meshPoints[1] || _meshTriangles[ii].Point3 == _meshPoints[1])
                    {
                        _meshTriangles.RemoveAt(ii);
                        continue;
                    }

                    if (_meshTriangles[ii].Point1 == _meshPoints[2] || _meshTriangles[ii].Point2 == _meshPoints[2] || _meshTriangles[ii].Point3 == _meshPoints[2])
                    {
                        _meshTriangles.RemoveAt(ii);
                        continue;
                    }
                }
                /*Step 6 done*/

                /*Step 7: Remove the supertriangle points from the mesh points list*/
                _meshPoints.RemoveAt(2);
                _meshPoints.RemoveAt(1);
                _meshPoints.RemoveAt(0);
                /*Step 7 done*/

                //Triangulation is done.
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private int ValidEdge(int iTriangleIndex, Point2d iPoint)
        {
            try
            {
                int FlipCount = 0;

                /*Step 5a: Find the triangle adjacent to the input triangle and opposite to iPoint*/
                Triangle InputTriangle = _meshTriangles[iTriangleIndex];
                //Triangle Opposite to iPoint
                Triangle OppositeTriangle = null;
                int OppositeTriangleIndex = 0;
                //Points opposite to iPoint
                Point2d OppositePoint = null;
                //The two points that make up the shared line segment which must be flipped
                Point2d OtherPoint1 = null;
                Point2d OtherPoint2 = null;

                for (int ii = 0; ii < _meshTriangles.Count; ii++)
                {
                    //Point1 of InputTriangle is the current point i.e. iPoint. So we find a triangle with other two points matching
                    if (InputTriangle.Point2 == _meshTriangles[ii].Point1 || InputTriangle.Point2 == _meshTriangles[ii].Point2 || InputTriangle.Point2 == _meshTriangles[ii].Point3)
                    {
                        if (InputTriangle.Point3 == _meshTriangles[ii].Point1 || InputTriangle.Point3 == _meshTriangles[ii].Point2 || InputTriangle.Point3 == _meshTriangles[ii].Point3)
                        {
                            if (InputTriangle.Point1 != _meshTriangles[ii].Point1 && InputTriangle.Point1 != _meshTriangles[ii].Point2 && InputTriangle.Point1 != _meshTriangles[ii].Point3)
                            {
                                //Found the opposite triangle
                                OppositeTriangle = _meshTriangles[ii];
                                OppositeTriangleIndex = ii;
                                //Now to find the opposite point and the two points that make up the shared line
                                if (_meshTriangles[ii].Point1 != InputTriangle.Point2 && _meshTriangles[ii].Point1 != InputTriangle.Point3)
                                {
                                    OppositePoint = _meshTriangles[ii].Point1;
                                    OtherPoint1 = _meshTriangles[ii].Point2;
                                    OtherPoint2 = _meshTriangles[ii].Point3;
                                }
                                else if (_meshTriangles[ii].Point2 != InputTriangle.Point2 && _meshTriangles[ii].Point2 != InputTriangle.Point3)
                                {
                                    OppositePoint = _meshTriangles[ii].Point2;
                                    OtherPoint1 = _meshTriangles[ii].Point1;
                                    OtherPoint2 = _meshTriangles[ii].Point3;
                                }
                                else if (_meshTriangles[ii].Point3 != InputTriangle.Point2 && _meshTriangles[ii].Point3 != InputTriangle.Point3)
                                {
                                    OppositePoint = _meshTriangles[ii].Point3;
                                    OtherPoint1 = _meshTriangles[ii].Point1;
                                    OtherPoint2 = _meshTriangles[ii].Point2;
                                }
                                break;
                            }
                        }
                    }

                }
                /*Step 5a done*/

                //If no triangle is opposite to iPoint, exit
                if (null == OppositeTriangle) return FlipCount;

                /*Step 5b: Check if iPoint is inside the circumcircle of the OppositeTriangle*/
                bool PointIsInCircumcircle = Tools.IsPointInsideCircumcircleOfTriangle(iPoint, OppositeTriangle);
                /*Step 5b done*/

                if (true == PointIsInCircumcircle)
                {
                    /*Step 5c: If point is inside the circumcircle of the opposite triangle, flip the edge.
                     This is done by removing the two triangles that share that edge and creating two new
                     triangles with the shared edge being that formed by iPoint and OppositePoint*/

                    //Remove the two triangles. The one with the higher index is removed first.
                    if (OppositeTriangleIndex > iTriangleIndex)
                    {
                        _meshTriangles.RemoveAt(OppositeTriangleIndex);
                        _meshTriangles.RemoveAt(iTriangleIndex);
                    }
                    else
                    {
                        _meshTriangles.RemoveAt(iTriangleIndex);
                        _meshTriangles.RemoveAt(OppositeTriangleIndex);
                    }

                    //Increase FlipCount to indicate that an edge is flipped
                    ++FlipCount;

                    //Create the two new triangles
                    _meshTriangles.Add(new Triangle(iPoint, OppositePoint, OtherPoint1));
                    int NewTriangle1Index = _meshTriangles.Count - 1;
                    _meshTriangles.Add(new Triangle(iPoint, OppositePoint, OtherPoint2));
                    int NewTriangle2Index = _meshTriangles.Count - 1;

                    //Run ValidEdge recursively, which performs recursive Edge-flipping, till all edges are legal.
                    //tempFlipCount keeps track of the edge-flips done inside that particular call of ValidEdge.
                    //This number is added to FlipCount and returned.
                    int tempFlipCount = 0;
                    tempFlipCount = ValidEdge(NewTriangle2Index, iPoint);
                    FlipCount += tempFlipCount;
                    //NewTriangle1Index is subtracted by tempFlipCount because, in the previous ValidEdge call, there
                    //will have been "tempFlipCount" number of edge-flips which deletes the same number of triangles
                    //below the NewTriangle1Index. So the index of the triangle at NewTriangle1Index will move down
                    //by tempFlipCount.
                    tempFlipCount = ValidEdge(NewTriangle1Index - tempFlipCount, iPoint);
                    FlipCount += tempFlipCount;
                }

                return FlipCount;
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.ToString());
                return 0;
            }
        }

        private void DisplayLines()
        {
            try
            {
                //Algorithm used is as follows:
                //Step 1: Select a point.
                //Step 2: Find all the triangles that contain that point
                //Step 3: Display the lines of the triangle that include that point.
                //          Check whether the other point of the line is included in the internal list "DisplayedPoints"
                //Step 4: Add that point to the internal list that contains all points whose lines have been displayed i.e. "DisplayedPoints"
                //Step 5: Repeat for all points

                List<Point2d> DisplayedPoints = new List<Point2d>();
                List<Triangle> TrianglesContainingPoint = new List<Triangle>();

                /*Step 1: Select a point*/
                for (int ii = 0; ii < _meshPoints.Count; ii++)
                /*Step 1 done*/
                {
                    /*Step 2: Find all the triangles that contain this point*/
                    for (int jj = 0; jj < _meshTriangles.Count; jj++)
                    {
                        if (_meshTriangles[jj].Point1 == _meshPoints[ii] || _meshTriangles[jj].Point2 == _meshPoints[ii] || _meshTriangles[jj].Point3 == _meshPoints[ii])
                        {
                            TrianglesContainingPoint.Add(_meshTriangles[jj]);
                        }
                    }
                    /*Step 2 done*/

                    /*Step 3: Display the lines, of those triangles, that are formed from _meshPoints[ii]*/
                    //This list signifies points that this current point has already been connected to. 
                    //Helps to avoid recreating lines that already exist
                    List<Point2d> AlreadyConnectedPoints = new List<Point2d>();
                    for (int jj = 0; jj < TrianglesContainingPoint.Count; jj++)
                    {
                        if (TrianglesContainingPoint[jj].Point1 == _meshPoints[ii])
                        {
                            //If neither of the other two points in this triangle has already been displayed, then proceed
                            if (!DisplayedPoints.Contains(TrianglesContainingPoint[jj].Point2) && !AlreadyConnectedPoints.Contains(TrianglesContainingPoint[jj].Point2))
                            {
                                _sketch.SketchLines.AddByTwoPoints(TrianglesContainingPoint[jj].Point1, TrianglesContainingPoint[jj].Point2);
                                AlreadyConnectedPoints.Add(TrianglesContainingPoint[jj].Point2);
                            }
                            if(!DisplayedPoints.Contains(TrianglesContainingPoint[jj].Point3) && !AlreadyConnectedPoints.Contains(TrianglesContainingPoint[jj].Point3))
                            { 
                                _sketch.SketchLines.AddByTwoPoints(TrianglesContainingPoint[jj].Point1, TrianglesContainingPoint[jj].Point3);
                                AlreadyConnectedPoints.Add(TrianglesContainingPoint[jj].Point3);
                            }
                        }
                        else if (TrianglesContainingPoint[jj].Point2 == _meshPoints[ii])
                        {
                            if (!DisplayedPoints.Contains(TrianglesContainingPoint[jj].Point1) && !AlreadyConnectedPoints.Contains(TrianglesContainingPoint[jj].Point1))
                            {
                                _sketch.SketchLines.AddByTwoPoints(TrianglesContainingPoint[jj].Point2, TrianglesContainingPoint[jj].Point1);
                                AlreadyConnectedPoints.Add(TrianglesContainingPoint[jj].Point1);
                            }
                            if(!DisplayedPoints.Contains(TrianglesContainingPoint[jj].Point3) && !AlreadyConnectedPoints.Contains(TrianglesContainingPoint[jj].Point3))
                            {
                                _sketch.SketchLines.AddByTwoPoints(TrianglesContainingPoint[jj].Point2, TrianglesContainingPoint[jj].Point3);
                                AlreadyConnectedPoints.Add(TrianglesContainingPoint[jj].Point3);
                            }
                        }
                        else
                        {
                            if (!DisplayedPoints.Contains(TrianglesContainingPoint[jj].Point1) && !AlreadyConnectedPoints.Contains(TrianglesContainingPoint[jj].Point1))
                            {
                                _sketch.SketchLines.AddByTwoPoints(TrianglesContainingPoint[jj].Point3, TrianglesContainingPoint[jj].Point1);
                                AlreadyConnectedPoints.Add(TrianglesContainingPoint[jj].Point1);
                            }
                            if(!DisplayedPoints.Contains(TrianglesContainingPoint[jj].Point2) && !AlreadyConnectedPoints.Contains(TrianglesContainingPoint[jj].Point2))
                            { 
                                _sketch.SketchLines.AddByTwoPoints(TrianglesContainingPoint[jj].Point3, TrianglesContainingPoint[jj].Point2);
                                AlreadyConnectedPoints.Add(TrianglesContainingPoint[jj].Point2);
                            }
                        }
                    }
                    /*Step 3 done*/

                    /*Step 4: Add this point to the list of displayed points*/
                    DisplayedPoints.Add(_meshPoints[ii]);
                    /*Step 4 done*/

                    TrianglesContainingPoint.Clear();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
    }
}
