﻿namespace Triangulator_InventorForm
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ConnectButton = new System.Windows.Forms.Button();
            this.CollectPointsButton = new System.Windows.Forms.Button();
            this.BeginTriangulationButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // ConnectButton
            // 
            this.ConnectButton.Location = new System.Drawing.Point(141, 29);
            this.ConnectButton.Name = "ConnectButton";
            this.ConnectButton.Size = new System.Drawing.Size(113, 33);
            this.ConnectButton.TabIndex = 0;
            this.ConnectButton.Text = "Connect";
            this.ConnectButton.UseVisualStyleBackColor = true;
            this.ConnectButton.Click += new System.EventHandler(this.OnConnectButtonClick);
            // 
            // CollectPointsButton
            // 
            this.CollectPointsButton.Location = new System.Drawing.Point(141, 119);
            this.CollectPointsButton.Name = "CollectPointsButton";
            this.CollectPointsButton.Size = new System.Drawing.Size(113, 33);
            this.CollectPointsButton.TabIndex = 1;
            this.CollectPointsButton.Text = "Collect Points";
            this.CollectPointsButton.UseVisualStyleBackColor = true;
            this.CollectPointsButton.Click += new System.EventHandler(this.OnCollectPointsButtonClick);
            this.CollectPointsButton.Enabled = false;
            // 
            // BeginTriangulationButton
            // 
            this.BeginTriangulationButton.Location = new System.Drawing.Point(106, 206);
            this.BeginTriangulationButton.Name = "BeginTriangulationButton";
            this.BeginTriangulationButton.Size = new System.Drawing.Size(182, 45);
            this.BeginTriangulationButton.TabIndex = 2;
            this.BeginTriangulationButton.Text = "Begin Triangulation";
            this.BeginTriangulationButton.UseVisualStyleBackColor = true;
            this.BeginTriangulationButton.Click += new System.EventHandler(this.OnBeginTriangulationButtonClick);
            this.BeginTriangulationButton.Enabled = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(386, 289);
            this.Controls.Add(this.BeginTriangulationButton);
            this.Controls.Add(this.CollectPointsButton);
            this.Controls.Add(this.ConnectButton);
            this.Name = "Form1";
            this.Text = "Delaunay Triangulation Form";
            //this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button ConnectButton;
        private System.Windows.Forms.Button CollectPointsButton;
        private System.Windows.Forms.Button BeginTriangulationButton;
    }
}

