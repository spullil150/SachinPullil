﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Inventor;

namespace Triangulator_InventorForm
{
    class Triangle
    {
        public Triangle(Point2d Point1, Point2d Point2, Point2d Point3)
        {
            _point1 = Point1;
            _point2 = Point2;
            _point3 = Point3;
        }

        Point2d _point1, _point2, _point3;

        public Point2d Point1
        {
            get
            {
                return this._point1;
            }
        }

        public Point2d Point2
        {
            get
            {
                return this._point2;
            }
        }

        public Point2d Point3
        {
            get
            {
                return this._point3;
            }
        }
    }
}
