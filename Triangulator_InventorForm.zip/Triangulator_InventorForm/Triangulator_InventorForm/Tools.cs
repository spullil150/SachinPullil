﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Inventor;

namespace Triangulator_InventorForm
{
    class Tools
    {
        public Tools() { }

        public static bool IsPointInsideTriangle(Point2d iPoint, Triangle iTria)
        {
            //If Area of triangle is equal to the sum of the areas of the three triangles made by connecting
            //iPoint to the three vertices, then iPoint is inside the Triangle
            double Area, Area1, Area2, Area3, AreaSum;
            Area = GetAreaOfTriangle(iTria.Point1, iTria.Point2, iTria.Point3);
            Area1 = GetAreaOfTriangle(iPoint, iTria.Point1, iTria.Point2);
            Area2 = GetAreaOfTriangle(iPoint, iTria.Point2, iTria.Point3);
            Area3 = GetAreaOfTriangle(iPoint, iTria.Point3, iTria.Point1);
            AreaSum = Area1 + Area2 + Area3;
            if (Math.Abs(Area - AreaSum) <0.0001)
                return true;
            else
                return false;
        }

        public static double GetAreaOfTriangle(Point2d pt1, Point2d pt2, Point2d pt3)
        {
            double area = Math.Abs( 0.5 * (pt1.X * (pt2.Y - pt3.Y) + pt2.X * (pt3.Y - pt1.Y) + pt3.X * (pt1.Y - pt2.Y)) );
            return area;
        }

        public static bool IsPointInsideCircumcircleOfTriangle(Point2d p, Triangle Tri)
        {
            double MidPt1X, MidPt1Y, MidPt2X, MidPt2Y, TangSlope1, TangSlope2, YInt1, YInt2, CentreX = 0, CentreY = 0, RadiusSqr, DistSqr;
            //First find the midpoint between the first two points
            MidPt1X = (Tri.Point1.X + Tri.Point2.X) / 2;
            MidPt1Y = (Tri.Point1.Y + Tri.Point2.Y) / 2;
            //Do it again for the second two points
            MidPt2X = (Tri.Point3.X + Tri.Point2.X) / 2;
            MidPt2Y = (Tri.Point3.Y + Tri.Point2.Y) / 2;
            //Find the tangent slope
            if (0 == (Tri.Point1.Y - Tri.Point2.Y)) // First tangent line is vertical
            {
                double XInt1 = MidPt1X;
                //Now we have the line x = XInt1
                TangSlope2 = -1 * (Tri.Point3.X - Tri.Point2.X) / (Tri.Point3.Y - Tri.Point2.Y);
                YInt2 = MidPt2Y - MidPt2X * TangSlope2;
                //Now we have the line y = TangSlope2x + YInt2
                //Now equate to find CentreX and CentreY i.e. Coordinates of the center point
                CentreX = XInt1;
                CentreY = TangSlope2 * XInt1 + YInt2;
            }
            else if (0 == (Tri.Point3.Y - Tri.Point2.Y)) //Second tangent line is vertical
            {
                TangSlope1 = -1 * (Tri.Point1.X - Tri.Point2.X) / (Tri.Point1.Y - Tri.Point2.Y);
                YInt1 = MidPt1Y - MidPt1X * TangSlope1;
                //Now we have the line y = TangSlope1x + YInt1
                double Xint2 = MidPt2X;
                //Now we have the line x = XInt2;
                //Now equate to find CentreX and CentreY i.e. Coordinates of the center point
                CentreX = Xint2;
                CentreY = TangSlope1 * Xint2 + YInt1;
            }
            else
            {
                TangSlope1 = -1 * (Tri.Point1.X - Tri.Point2.X) / (Tri.Point1.Y - Tri.Point2.Y);
                YInt1 = MidPt1Y - MidPt1X * TangSlope1;
                //Now we have the line y = TangSlope1x + YInt1
                TangSlope2 = -1 * (Tri.Point3.X - Tri.Point2.X) / (Tri.Point3.Y - Tri.Point2.Y);
                YInt2 = MidPt2Y - MidPt2X * TangSlope2;
                //Now we have the line y = TangSlope2x + YInt2
                //Now equate to find CentreX and CentreY i.e. Coordinates of the center point
                CentreX = (YInt1 - YInt2) / (TangSlope2 - TangSlope1);
                CentreY = TangSlope1 * CentreX + YInt1;
            }
            

            //Now that we have the center point, we find the radius squared from (CentreX,CentreY) to (x1,y1)
            RadiusSqr = (Tri.Point1.X - CentreX) * (Tri.Point1.X - CentreX) + (Tri.Point1.Y - CentreY) * (Tri.Point1.Y - CentreY);
            //Now distance squared b/w (CentreX,CentreY) and the given point
            DistSqr = (p.X - CentreX) * (p.X - CentreX) + (p.Y - CentreY) * (p.Y - CentreY);

            if (RadiusSqr > DistSqr) //Point is inside triangle
                return true;
            else
                return false;
        }

    }
}
