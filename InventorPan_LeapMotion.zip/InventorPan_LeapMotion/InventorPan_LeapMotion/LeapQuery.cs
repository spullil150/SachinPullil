﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Leap;

namespace InventorPan_LeapMotion
{
    class LeapQuery
    {
        Leap.Controller _controller;
        FormClass _formClass;
        InventorControl _invControl;
        Frame _frame;
        Finger _indexFinger;
        Leap.Vector _indexPosVec;
        Leap.Vector _indexVelVec;

        float _fPrevX;
        float _fPrevY;
        bool _bPanLockOn;
        int _frameCount;
        
        float _fXPos;
        float _fYPos;
        float _fZPos;
        float _fXVel;
        float _fYVel;
        float _fZVel;

        public LeapQuery(FormClass iFormClass, InventorControl iInventorControl)
        {
            _formClass = iFormClass;
            _invControl = iInventorControl;
            _fPrevX = 0;
            _fPrevY = (float)0.1; //Initialize in metres
            _bPanLockOn = false;
            _frameCount = 0;
        }

        public bool ConnectToLeapMotion()
        {
            try
            {
                _controller = new Leap.Controller();

                _controller.FrameReady += this.OnFrameReady;
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
                return false;
            }
        }

        public void OnFrameReady(object sender, FrameEventArgs e)
        {
            try
            {
                _frame = e.frame;

                //Pan only if one hand is present and Pan is ON
                if (1 == _frame.Hands.Count)
                {
                    _indexFinger = _frame.Hands[0].Fingers[1];
                    _indexPosVec = _indexFinger.StabilizedTipPosition;
                    _indexVelVec = _indexFinger.TipVelocity;

                    _fXPos = (float)Math.Round((decimal)_indexPosVec.x);
                    _fYPos = (float)Math.Round((decimal)_indexPosVec.y);
                    _fZPos = (float)Math.Round((decimal)_indexPosVec.z);
                    _formClass.SetXYZPositionOnForm(_fXPos, _fYPos, _fZPos);

                    _frameCount++;
                    _fXVel = (float)Math.Round((decimal)_indexVelVec.x);
                    _fYVel = (float)Math.Round((decimal)_indexVelVec.y);
                    _fZVel = (float)Math.Round((decimal)_indexVelVec.z);
                    if (0 == _frameCount % 10)
                    {
                        //Velocity fluctuates too much so only every 10th frame's velocity is displayed
                        _formClass.SetXYZVelocityOnForm(_fXVel, _fYVel, _fZVel);
                    }

                    //1. Check if positions reach lock position or if Pan is locked on. Once lock is set, no need to check for X&Y position
                    //2. Check if the finger is in the Z<0 region in space
                    //3. Check if the Z velocity is less than 200 (if more, implies user is removing finger)
                    if ((_bPanLockOn && (_fZPos < 0) && (_fZVel < 200)) ||
                        ((Math.Abs(_fXPos - 0) < 20) && (Math.Abs(_fYPos - 100) < 20) && (_fZPos < 0)))
                    {
                        if (true != _bPanLockOn)
                        {
                            _bPanLockOn = true;
                            _formClass.SetFingerLockedOnStatusOnForm(_bPanLockOn);
                        }

                        _fXPos *= (float)0.001; //Conversion to meters
                        _fYPos *= (float)0.001;
                        _fZPos *= (float)0.001;

                        //1. Check if new fXPos and fYPos are sufficiently different from old ones
                        //2. Check if the X||Y velocity is >25. If <25, probably unintended finger movement from user
                        if (((Math.Abs(_fXPos - _fPrevX) > 0.002) && (Math.Abs(_fYPos - _fPrevY) > 0.002)) &&
                            (Math.Abs(_fXVel) > 25 || Math.Abs(_fYVel) > 25))
                        {
                            //Then start panning
                            _invControl.Pan(_fXPos - _fPrevX, _fYPos - _fPrevY);

                            _fPrevX = _fXPos;
                            _fPrevY = _fYPos;
                        }

                    }
                    else
                    {
                        if (true == _bPanLockOn)
                        {
                            _bPanLockOn = false;
                            _formClass.SetFingerLockedOnStatusOnForm(_bPanLockOn);
                        }
                    }
                }
                else
                {
                    _formClass.SetXYZPositionOnForm(0, 0, 0);
                    _formClass.SetXYZVelocityOnForm(0, 0, 0);
                    if (false != _bPanLockOn)
                    {
                        _bPanLockOn = false;
                        _formClass.SetFingerLockedOnStatusOnForm(_bPanLockOn);
                    }
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
    }
}
