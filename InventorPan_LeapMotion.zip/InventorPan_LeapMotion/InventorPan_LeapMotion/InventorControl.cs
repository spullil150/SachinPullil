﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Inventor;

namespace InventorPan_LeapMotion
{
    class InventorControl
    {
        Inventor.Application _invApplication;
        Inventor.TransientGeometry _invTransGeo;
        Inventor.Camera _camera;
        Inventor.Point _eye;
        Inventor.Point _target;
        Inventor.UnitVector _upVector;
        Inventor.Vector _eyeVector;
        Inventor.Vector _targetVector;
        Inventor.Vector _target2eyeVector;
        Inventor.Vector _leftVector;
        double _dWidth;
        double _dHeight;

        public InventorControl()
        {

        }

        public bool ConnectToInventor()
        {
            try
            {
                _invApplication = (Inventor.Application)System.Runtime.InteropServices.Marshal.GetActiveObject("Inventor.Application");
                InitializeVariables();
                return true;
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.ToString());
                return false;
            }
        }

        private void InitializeVariables()
        {
            //Get the camera
            _invTransGeo = (Inventor.TransientGeometry)_invApplication.TransientGeometry;
            Inventor.View view = (Inventor.View)_invApplication.ActiveView;
            _camera = view.Camera;

            //Get information from the camera
            _camera.GetExtents(out _dWidth, out _dHeight);
            _eye = _camera.Eye;
            _eyeVector = _invTransGeo.CreateVector(_eye.X, _eye.Y, _eye.Z);
            _target = _camera.Target;
            _targetVector = _invTransGeo.CreateVector(_target.X, _target.Y, _target.Z);
            _upVector = _camera.UpVector;

            Inventor.Vector tempVector = _eyeVector.Copy();
            tempVector.SubtractVector(_targetVector);
            _target2eyeVector = tempVector.Copy();

            tempVector = _upVector.AsVector();
            _leftVector = _target2eyeVector.CrossProduct(tempVector);
        }

        public void Pan(float ifDeltaX, float ifDeltaY)
        {
            try
            {
                //Scale based on the width/height of view
                ifDeltaX *= (float)(_dWidth);
                ifDeltaY *= (float)(_dHeight * 3);

                //Scale _leftVector based on X movement
                Inventor.Vector tempVector = _leftVector.Copy();
                tempVector.ScaleBy((double)ifDeltaX);
                _eyeVector.AddVector(tempVector);
                _targetVector.AddVector(tempVector);

                //Scale _upVector based on Y movement
                tempVector = (_upVector.AsVector()).Copy();
                tempVector.ScaleBy((double)ifDeltaY);
                _eyeVector.SubtractVector(tempVector);
                _targetVector.SubtractVector(tempVector);

                _eye.X = _eyeVector.X;
                _eye.Y = _eyeVector.Y;
                _eye.Z = _eyeVector.Z;
                _target.X = _targetVector.X;
                _target.Y = _targetVector.Y;
                _target.Z = _targetVector.Z;

                //Apply these new vectors to the camera
                _camera.Eye = _eye;
                _camera.Target = _target;
                _camera.ApplyWithoutTransition();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
    }
}
