﻿namespace InventorPan_LeapMotion
{
    partial class FormClass
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cmdConnectLeapMotion = new System.Windows.Forms.Button();
            this.cmdConnectInventor = new System.Windows.Forms.Button();
            this.txtLeapMotionStatus = new System.Windows.Forms.Label();
            this.txtInventorStatus = new System.Windows.Forms.Label();
            this.txtPanLockStatus = new System.Windows.Forms.Label();
            this.XLabel = new System.Windows.Forms.Label();
            this.YLabel = new System.Windows.Forms.Label();
            this.ZLabel = new System.Windows.Forms.Label();
            this.XPositionLabel = new System.Windows.Forms.Label();
            this.YPositionLabel = new System.Windows.Forms.Label();
            this.ZPositionLabel = new System.Windows.Forms.Label();
            this.XYVelocityLabel = new System.Windows.Forms.Label();
            this.YYVelocityLabel = new System.Windows.Forms.Label();
            this.ZYVelocityLabel = new System.Windows.Forms.Label();
            this.XVelocityLabel = new System.Windows.Forms.Label();
            this.YVelocityLabel = new System.Windows.Forms.Label();
            this.ZVelocityLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // cmdConnectLeapMotion
            // 
            this.cmdConnectLeapMotion.Location = new System.Drawing.Point(37, 31);
            this.cmdConnectLeapMotion.Name = "cmdConnectLeapMotion";
            this.cmdConnectLeapMotion.Size = new System.Drawing.Size(143, 44);
            this.cmdConnectLeapMotion.TabIndex = 0;
            this.cmdConnectLeapMotion.Text = "Connect to Leap Motion";
            this.cmdConnectLeapMotion.UseVisualStyleBackColor = true;
            this.cmdConnectLeapMotion.Click += new System.EventHandler(this.cmdConnectLeapMotion_Click);
            // 
            // cmdConnectInventor
            // 
            this.cmdConnectInventor.Location = new System.Drawing.Point(262, 31);
            this.cmdConnectInventor.Name = "cmdConnectInventor";
            this.cmdConnectInventor.Size = new System.Drawing.Size(143, 44);
            this.cmdConnectInventor.TabIndex = 1;
            this.cmdConnectInventor.Text = "Connect to Inventor";
            this.cmdConnectInventor.UseVisualStyleBackColor = true;
            this.cmdConnectInventor.Click += new System.EventHandler(this.cmdConnectInventor_Click);
            // 
            // txtLeapMotionStatus
            // 
            this.txtLeapMotionStatus.AutoSize = true;
            this.txtLeapMotionStatus.Location = new System.Drawing.Point(12, 90);
            this.txtLeapMotionStatus.Name = "txtLeapMotionStatus";
            this.txtLeapMotionStatus.Size = new System.Drawing.Size(198, 17);
            this.txtLeapMotionStatus.TabIndex = 2;
            this.txtLeapMotionStatus.Text = "Not connected to Leap Motion";
            // 
            // txtInventorStatus
            // 
            this.txtInventorStatus.AutoSize = true;
            this.txtInventorStatus.Location = new System.Drawing.Point(246, 90);
            this.txtInventorStatus.Name = "txtInventorStatus";
            this.txtInventorStatus.Size = new System.Drawing.Size(171, 17);
            this.txtInventorStatus.TabIndex = 3;
            this.txtInventorStatus.Text = "Not connected to Inventor";
            // 
            // txtPanLockStatus
            // 
            this.txtPanLockStatus.AutoSize = true;
            this.txtPanLockStatus.Location = new System.Drawing.Point(116, 129);
            this.txtPanLockStatus.Name = "txtPanLockStatus";
            this.txtPanLockStatus.Size = new System.Drawing.Size(204, 17);
            this.txtPanLockStatus.TabIndex = 4;
            this.txtPanLockStatus.Text = "Finger not locked onto Inventor";
            // 
            // XLabel
            // 
            this.XLabel.AutoSize = true;
            this.XLabel.Location = new System.Drawing.Point(37, 175);
            this.XLabel.Name = "XLabel";
            this.XLabel.Size = new System.Drawing.Size(25, 17);
            this.XLabel.TabIndex = 5;
            this.XLabel.Text = "X: ";
            // 
            // YLabel
            // 
            this.YLabel.AutoSize = true;
            this.YLabel.Location = new System.Drawing.Point(37, 196);
            this.YLabel.Name = "YLabel";
            this.YLabel.Size = new System.Drawing.Size(25, 17);
            this.YLabel.TabIndex = 6;
            this.YLabel.Text = "Y: ";
            // 
            // ZLabel
            // 
            this.ZLabel.AutoSize = true;
            this.ZLabel.Location = new System.Drawing.Point(37, 217);
            this.ZLabel.Name = "ZLabel";
            this.ZLabel.Size = new System.Drawing.Size(25, 17);
            this.ZLabel.TabIndex = 7;
            this.ZLabel.Text = "Z: ";
            // 
            // XPositionLabel
            // 
            this.XPositionLabel.AutoSize = true;
            this.XPositionLabel.Location = new System.Drawing.Point(77, 175);
            this.XPositionLabel.Name = "XPositionLabel";
            this.XPositionLabel.Size = new System.Drawing.Size(16, 17);
            this.XPositionLabel.TabIndex = 8;
            this.XPositionLabel.Text = "0";
            // 
            // YPositionLabel
            // 
            this.YPositionLabel.AutoSize = true;
            this.YPositionLabel.Location = new System.Drawing.Point(77, 196);
            this.YPositionLabel.Name = "YPositionLabel";
            this.YPositionLabel.Size = new System.Drawing.Size(16, 17);
            this.YPositionLabel.TabIndex = 9;
            this.YPositionLabel.Text = "0";
            // 
            // ZPositionLabel
            // 
            this.ZPositionLabel.AutoSize = true;
            this.ZPositionLabel.Location = new System.Drawing.Point(77, 217);
            this.ZPositionLabel.Name = "ZPositionLabel";
            this.ZPositionLabel.Size = new System.Drawing.Size(16, 17);
            this.ZPositionLabel.TabIndex = 10;
            this.ZPositionLabel.Text = "0";
            // 
            // XYVelocityLabel
            // 
            this.XYVelocityLabel.AutoSize = true;
            this.XYVelocityLabel.Location = new System.Drawing.Point(151, 175);
            this.XYVelocityLabel.Name = "XYVelocityLabel";
            this.XYVelocityLabel.Size = new System.Drawing.Size(78, 17);
            this.XYVelocityLabel.TabIndex = 11;
            this.XYVelocityLabel.Text = "X Velocity: ";
            // 
            // YYVelocityLabel
            // 
            this.YYVelocityLabel.AutoSize = true;
            this.YYVelocityLabel.Location = new System.Drawing.Point(151, 196);
            this.YYVelocityLabel.Name = "YYVelocityLabel";
            this.YYVelocityLabel.Size = new System.Drawing.Size(78, 17);
            this.YYVelocityLabel.TabIndex = 12;
            this.YYVelocityLabel.Text = "Y Velocity: ";
            // 
            // ZYVelocityLabel
            // 
            this.ZYVelocityLabel.AutoSize = true;
            this.ZYVelocityLabel.Location = new System.Drawing.Point(151, 217);
            this.ZYVelocityLabel.Name = "ZYVelocityLabel";
            this.ZYVelocityLabel.Size = new System.Drawing.Size(78, 17);
            this.ZYVelocityLabel.TabIndex = 13;
            this.ZYVelocityLabel.Text = "Z Velocity: ";
            // 
            // XVelocityLabel
            // 
            this.XVelocityLabel.AutoSize = true;
            this.XVelocityLabel.Location = new System.Drawing.Point(248, 175);
            this.XVelocityLabel.Name = "XVelocityLabel";
            this.XVelocityLabel.Size = new System.Drawing.Size(16, 17);
            this.XVelocityLabel.TabIndex = 14;
            this.XVelocityLabel.Text = "0";
            // 
            // YVelocityLabel
            // 
            this.YVelocityLabel.AutoSize = true;
            this.YVelocityLabel.Location = new System.Drawing.Point(248, 196);
            this.YVelocityLabel.Name = "YVelocityLabel";
            this.YVelocityLabel.Size = new System.Drawing.Size(16, 17);
            this.YVelocityLabel.TabIndex = 15;
            this.YVelocityLabel.Text = "0";
            // 
            // ZVelocityLabel
            // 
            this.ZVelocityLabel.AutoSize = true;
            this.ZVelocityLabel.Location = new System.Drawing.Point(248, 217);
            this.ZVelocityLabel.Name = "ZVelocityLabel";
            this.ZVelocityLabel.Size = new System.Drawing.Size(16, 17);
            this.ZVelocityLabel.TabIndex = 16;
            this.ZVelocityLabel.Text = "0";
            // 
            // FormClass
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(439, 250);
            this.Controls.Add(this.ZVelocityLabel);
            this.Controls.Add(this.YVelocityLabel);
            this.Controls.Add(this.XVelocityLabel);
            this.Controls.Add(this.ZYVelocityLabel);
            this.Controls.Add(this.YYVelocityLabel);
            this.Controls.Add(this.XYVelocityLabel);
            this.Controls.Add(this.ZPositionLabel);
            this.Controls.Add(this.YPositionLabel);
            this.Controls.Add(this.XPositionLabel);
            this.Controls.Add(this.ZLabel);
            this.Controls.Add(this.YLabel);
            this.Controls.Add(this.XLabel);
            this.Controls.Add(this.txtLeapMotionStatus);
            this.Controls.Add(this.txtPanLockStatus);
            this.Controls.Add(this.txtInventorStatus);
            this.Controls.Add(this.cmdConnectInventor);
            this.Controls.Add(this.cmdConnectLeapMotion);
            this.Name = "FormClass";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button cmdConnectLeapMotion;
        private System.Windows.Forms.Button cmdConnectInventor;
        private System.Windows.Forms.Label txtLeapMotionStatus;
        private System.Windows.Forms.Label txtInventorStatus;
        private System.Windows.Forms.Label txtPanLockStatus;
        private System.Windows.Forms.Label XLabel;
        private System.Windows.Forms.Label YLabel;
        private System.Windows.Forms.Label ZLabel;
        private System.Windows.Forms.Label XPositionLabel;
        private System.Windows.Forms.Label YPositionLabel;
        private System.Windows.Forms.Label ZPositionLabel;
        private System.Windows.Forms.Label XYVelocityLabel;
        private System.Windows.Forms.Label YYVelocityLabel;
        private System.Windows.Forms.Label ZYVelocityLabel;
        private System.Windows.Forms.Label XVelocityLabel;
        private System.Windows.Forms.Label YVelocityLabel;
        private System.Windows.Forms.Label ZVelocityLabel;
    }
}

