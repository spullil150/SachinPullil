﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InventorPan_LeapMotion
{
    public partial class FormClass : Form
    {
        LeapQuery _leapQuery;
        InventorControl _invControl;       

        public FormClass()
        {
            InitializeComponent();
            _invControl = new InventorControl();
            _leapQuery = new LeapQuery(this, _invControl);            
        }

        private void cmdConnectLeapMotion_Click(object sender, EventArgs e)
        {
            try
            {
                bool bResult = _leapQuery.ConnectToLeapMotion();
                if(bResult)
                {
                    this.cmdConnectLeapMotion.Enabled = false;
                    this.txtLeapMotionStatus.Text = "Connected to Leap Motion";
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void cmdConnectInventor_Click(object sender, EventArgs e)
        {
            try
            {
                bool bResult = _invControl.ConnectToInventor();
                if(bResult)
                {
                    this.cmdConnectInventor.Enabled = false;
                    this.txtInventorStatus.Text = "Connected to Inventor";
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        //Sets the X,Y and Z coordinates sent by Leap Motion into the windows form
        public void SetXYZPositionOnForm(float iX, float iY, float iZ)
        {
            this.XPositionLabel.Text = iX.ToString();
            this.YPositionLabel.Text = iY.ToString();
            this.ZPositionLabel.Text = iZ.ToString();
        }

        //Sets the message on the form if the finger is locked on
        public void SetFingerLockedOnStatusOnForm(bool ibLockOnStatus)
        {
            if (ibLockOnStatus)
                this.txtPanLockStatus.Text = "Finger LOCKED ON to Inventor";
            else
                this.txtPanLockStatus.Text = "Finger not locked onto Inventor";
        }

        //Sets the X,Y and Z velocities sent by Leap Motion into the windows form
        public void SetXYZVelocityOnForm(float iX, float iY, float iZ)
        {
            this.XVelocityLabel.Text = iX.ToString();
            this.YVelocityLabel.Text = iY.ToString();
            this.ZVelocityLabel.Text = iZ.ToString();
        }        
    }
}
